package com.modulodocente.backend.controller;

import com.modulodocente.backend.entity.Usuario;
import com.modulodocente.backend.repository.UsuarioRepository;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "http://localhost:5173")
public class UsuarioController {

    private final UsuarioRepository usuarioRepository;

    public UsuarioController(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @PostMapping("/login")
    public Mono<ResponseEntity<String>> login(@RequestBody Mono<Map<String, String>> loginDataMono) {
        return loginDataMono.flatMap(loginData -> {
            String email = loginData.get("email");
            String password = loginData.get("password");

            return usuarioRepository.findByUsername(email)
                .map(usuario -> {
                    if (usuario.getPassword().equals(password)) {
                        return ResponseEntity.ok("Login exitoso");
                    } else {
                        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Contraseña incorrecta");
                    }
                })
                .defaultIfEmpty(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado"));
        });
    }
}
