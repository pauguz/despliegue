package com.modulodocente.backend.controller;

import com.modulodocente.backend.dto.DocenteRequestDTO;
import com.modulodocente.backend.entity.Docente;
import com.modulodocente.backend.entity.Usuario;
import com.modulodocente.backend.repository.DocenteRepository;
import com.modulodocente.backend.repository.UsuarioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/docentes")
@CrossOrigin(origins = "http://localhost:5173")
public class DocenteController {

    @Autowired
    private DocenteRepository docenteRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @PostMapping("/registrar")
    public Mono<ResponseEntity<?>> registrarDocente(@RequestBody DocenteRequestDTO request) {
        if (!request.password.equals(request.confirmPassword)) {
            return Mono.just(ResponseEntity.badRequest().body("Las contraseñas no coinciden."));
        }

        if (!request.email.endsWith("@unmsm.edu.pe")) {
            return Mono.just(ResponseEntity.badRequest().body("El correo debe terminar en @unmsm.edu.pe."));
        }

        return usuarioRepository.existsByUsername(request.email)
            .flatMap(existeUsuario -> {
                if (existeUsuario) {
                    return Mono.just(ResponseEntity.badRequest().body("Ya existe un usuario con ese correo."));
                }

                return docenteRepository.existsByCodigo(request.codigo)
                    .flatMap(existeCodigo -> {
                        if (existeCodigo) {
                            return Mono.just(ResponseEntity.badRequest().body("Ya existe un docente con ese código."));
                        }

                        Usuario usuario = new Usuario();
                        usuario.setUsername(request.email);
                        usuario.setPassword(request.password);
                        usuario.setNombrevisualizar(request.nombres + " " + request.apellidos);
                        usuario.setEstado("1");
                        usuario.setFechacreacion(LocalDateTime.now().toString());

                        return usuarioRepository.save(usuario)
                            .flatMap(usuarioGuardado -> {
                                Docente docente = new Docente();
                                docente.setCodigo(request.codigo);
                                docente.setNombres(request.nombres);
                                docente.setApellidos(request.apellidos);
                                docente.setEmail(request.email);
                                docente.setEstado("1");
                                docente.setClaseid(request.claseId);
                                docente.setCategoriaid(request.categoriaId);
                                docente.setUsuarioid(usuarioGuardado.getId());
                                docente.setInstitucionid(request.institucionId);
                                docente.setDepartamentoid(request.departamentoId);

                                return docenteRepository.save(docente)
                                    .thenReturn(ResponseEntity.ok("Registro exitoso"));
                            });
                    });
            });
    }
}
