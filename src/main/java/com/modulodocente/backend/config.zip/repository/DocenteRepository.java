package com.modulodocente.backend.repository;

import com.modulodocente.backend.entity.Docente;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface DocenteRepository extends ReactiveCrudRepository<Docente, Integer> {
    
    Mono<Boolean> existsByCodigo(String codigo);
}
