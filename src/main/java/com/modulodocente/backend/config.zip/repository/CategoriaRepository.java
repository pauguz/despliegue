package com.modulodocente.backend.repository;

import com.modulodocente.backend.entity.Categoria;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface CategoriaRepository extends ReactiveCrudRepository<Categoria, String> {
}