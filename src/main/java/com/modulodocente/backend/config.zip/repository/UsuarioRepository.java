package com.modulodocente.backend.repository;

import com.modulodocente.backend.entity.Usuario;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;

public interface UsuarioRepository extends ReactiveCrudRepository<Usuario, Integer> {
    Mono<Usuario> findByUsername(String username);
    Mono<Boolean> existsByUsername(String username);

}
