package com.modulodocente.backend.repository;

import com.modulodocente.backend.entity.Institucion;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

public interface InstitucionRepository extends ReactiveCrudRepository<Institucion, Integer> {
}
