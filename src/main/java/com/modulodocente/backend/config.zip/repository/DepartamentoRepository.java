package com.modulodocente.backend.repository;

import com.modulodocente.backend.entity.Departamento;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartamentoRepository extends ReactiveCrudRepository<Departamento, Long> {
}
