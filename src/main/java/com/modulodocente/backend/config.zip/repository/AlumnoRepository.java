package com.modulodocente.backend.repository;

import com.modulodocente.backend.entity.Alumno;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

public interface AlumnoRepository extends ReactiveCrudRepository<Alumno, Long> {

    Mono<Boolean> existsByCodigo(String codigo);
    Mono<Boolean> existsByEmail(String email);

    Mono<Alumno> findByCodigo(String codigo);
    Mono<Alumno> findByEmail(String email);

    Mono<Long> countByEstado(String estado);
    Flux<Alumno> findByInstitucionid(Integer institucionId);
}
