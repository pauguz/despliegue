package com.modulodocente.backend.dto;

public class DocenteRequestDTO {
    public String nombres;
    public String apellidos;
    public String codigo;
    public String email;
    public String password;
    public String confirmPassword;
    public String claseId;
    public String categoriaId;
    public Integer institucionId;
    public Long departamentoId;
}

